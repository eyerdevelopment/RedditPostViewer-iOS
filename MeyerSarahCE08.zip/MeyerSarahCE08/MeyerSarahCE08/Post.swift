import Foundation
import UIKit

enum ParsingError: Error {
    case postParsing
}

// Model object representing a Reddit post
class Post {
    
    // MARK: - Stored Properties
    let title: String
    let author: String
    var thumbImage: UIImage? = nil
    let numComments: Int
    let score: Int
    let date: Date
    let postText: String
    let subReddit: String
    var subArray: [String]
    let permalink: String
    
    // MARK: - Initializer
    init(jsonRedditPost post: [String: Any]) throws {
        
        // Required fields
        guard let title = post["title"] as? String,
              let author = post["author"] as? String,
              let numComments = post["num_comments"] as? Int,
              let score = post["score"] as? Int,
              let timestamp = post["created_utc"] as? TimeInterval,
              let subReddit = post["subreddit"] as? String
        else {
            throw ParsingError.postParsing
        }
        
        // Optional fields with fallback
        let postText = post["selftext"] as? String ?? ""
        let thumbString = post["thumbnail"] as? String ?? ""
        let permalink = post["permalink"] as? String ?? ""
        
        self.title = title
        self.author = author
        self.numComments = numComments
        self.score = score
        self.date = Date(timeIntervalSince1970: timestamp)
        self.postText = postText
        self.subReddit = subReddit
        self.subArray = [subReddit]
        self.permalink = permalink
        
        // Try loading thumbnail only if it's a valid URL
        if thumbString.hasPrefix("http"),
           let url = URL(string: thumbString),
           var components = URLComponents(url: url, resolvingAgainstBaseURL: false) {
            
            components.scheme = "https"
            
            if let secureURL = components.url {
                // Load thumbnail data safely and async later in UI, but if you really want it here:
                if let imageData = try? Data(contentsOf: secureURL) {
                    self.thumbImage = UIImage(data: imageData)
                }
            }
        }
    }
}
