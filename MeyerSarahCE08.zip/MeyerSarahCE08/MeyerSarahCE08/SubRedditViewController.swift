//
//  SubRedditViewController.swift
//  MeyerSarahCE08
//
//  Created by Sarah on 10/17/22.
//  Updated for portfolio use in 2025 by Sarah Meyer
//

import UIKit

class SubRedditViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - Outlets
    
    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var addTextField: UITextField!
    
    // MARK: - Properties
    
    var savedSub: [String] = []
    var posts: [Post]?
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: - TableView DataSource & Delegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return savedSub.count
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell_ID_2", for: indexPath) as? SubredditViewCell else {
            return UITableViewCell()
        }

        cell.subLabel.text = savedSub[indexPath.row]
        return cell
    }

    // MARK: - Button Actions

    /// Adds a new subreddit to the list and updates the table view
    @IBAction func addBtn(_ sender: Any) {
        guard let addedSub = addTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines),
              !addedSub.isEmpty else {
            return // Ignore empty input
        }
        
        savedSub.append(addedSub)
        table.reloadData()
        addTextField.text = ""
    }

    /// Saves the current subreddit list to UserDefaults
    @IBAction func saveBtn(_ sender: Any) {
        UserDefaults.standard.setSub(input: savedSub, forKey: "addSub")
    }

    /// Clears all subreddits from the list
    @IBAction func resetBtn(_ sender: Any) {
        savedSub.removeAll()
        table.reloadData()
    }
}

