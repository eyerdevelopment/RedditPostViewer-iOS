//
//  ViewController.swift
//  MeyerSarahCE08
//
//  Created by Sarah on 10/17/22.
//  Updated for portfolio use in 2025 by Sarah Meyer
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    // MARK: - Properties
    
    var posts: [Post] = []
    var filteredPosts: [[Post]] = [[]]
    var savedSub: [String] = []
    
    // Saved user color preferences
    var savedTitleColor: UIColor = .black
    var savedAuthorColor: UIColor = .black
    var savedViewColor: UIColor = .white

    @IBOutlet weak var table: UITableView!

    // MARK: - View Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Start with a default subreddit if user has no saved values
        savedSub = ["kittens"]
        
        // Load user preferences and subreddit data
        UserSavedValues()
        
        table.reloadData()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Reload saved values and refresh the table when view reappears
        UserSavedValues()
        table.reloadData()
    }

    // MARK: - TableView DataSource & Delegate
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return savedSub.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredPosts[section].count
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return savedSub[section]
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell_ID_1", for: indexPath) as? TableViewCell else {
            return UITableViewCell()
        }

        let post = filteredPosts[indexPath.section][indexPath.row]
        
        // If image is missing, remove the post (optional: replace this with a placeholder image)
        if post.thumbImage == nil {
            filteredPosts[indexPath.section].remove(at: indexPath.row)
            table.reloadData()
            return cell
        }

        // Apply saved colors
        cell.backgroundColor = savedViewColor
        cell.titleLabel.text = post.title
        cell.titleLabel.textColor = savedTitleColor
        cell.authorLabel.text = post.author
        cell.authorLabel.textColor = savedAuthorColor
        cell.imageLabel.image = post.thumbImage

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let post = filteredPosts[indexPath.section][indexPath.row]
        
        let fullURLString = "https://www.reddit.com\(post.permalink)"
        
        if let url = URL(string: fullURLString) {
            UIApplication.shared.open(url)
        } else {
            print("Invalid permalink: \(post.permalink)")
        }
        
        tableView.deselectRow(at: indexPath, animated: true)
    }


    // MARK: - User Defaults & Data Loading
    
    /// Loads all user-saved values including subreddits and color preferences
    func UserSavedValues() {
        // Load saved subreddit names
        if let userSavedSubs = UserDefaults.standard.getSub(forKey: "addSub") {
            savedSub = userSavedSubs
            
            // Ensure filteredPosts has a matching number of sections
            while filteredPosts.count < savedSub.count {
                filteredPosts.append([])
            }
        }

        // Fetch new posts for each subreddit
        for sub in savedSub where !sub.isEmpty {
            subRedditPicker(chosenSubReddit: sub)
        }

        // Load saved UI colors
        UserColorSavedValues()
    }

    /// Loads user-saved theme colors from UserDefaults
    func UserColorSavedValues() {
        if let userSavedTitleColor = UserDefaults.standard.color(forKey: "titleColor") {
            savedTitleColor = userSavedTitleColor
        }
        if let userSavedAuthorColor = UserDefaults.standard.color(forKey: "authorColor") {
            savedAuthorColor = userSavedAuthorColor
        }
        if let userSavedViewColor = UserDefaults.standard.color(forKey: "viewColor") {
            savedViewColor = userSavedViewColor
        }
    }

    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case "goToSubReddit":
            if let subVC = segue.destination as? SubRedditViewController {
                subVC.savedSub = savedSub
                subVC.posts = posts
            }
        case "goToTheme":
            _ = segue.destination as? ThemeViewController
        default:
            break
        }
    }

    // MARK: - Actions
    
    @IBAction func themeBtn(_ sender: Any) {
        // Placeholder action for theme button
    }

    @IBAction func unwindToFirst(_ unwindSegue: UIStoryboardSegue) {
        // Optional: handle actions when unwinding from other VCs
        if unwindSegue.source is SubRedditViewController {
            // Handle return from subreddit screen
        } else if unwindSegue.source is ThemeViewController {
            // Handle return from theme screen
        }
    }
}
