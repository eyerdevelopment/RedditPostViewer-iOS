//
//  ThemeViewController.swift
//  MeyerSarahCE08
//
//  Created by Sarah on 10/17/22.
//  Updated for portfolio use in 2025 by Sarah Meyer
//

import UIKit

class ThemeViewController: UIViewController {
    
    // MARK: - Outlets
    
    @IBOutlet weak var titleButton: UIButton!
    @IBOutlet weak var authorButton: UIButton!
    @IBOutlet weak var viewButton: UIButton!
    @IBOutlet weak var editingLabel: UILabel!
    
    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    
    // MARK: - Color Component Variables
    
    var red: Float = 0
    var green: Float = 0
    var blue: Float = 0
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: - Button Actions
    
    @IBAction func titleBtn(_ sender: Any) {
        editingLabel.text = "Editing: Title"
    }
    
    @IBAction func authorBtn(_ sender: Any) {
        editingLabel.text = "Editing: Author"
        applySliderColor(to: authorButton)
    }
    
    @IBAction func viewBtn(_ sender: Any) {
        editingLabel.text = "Editing: View"
        applySliderColor(to: viewButton)
    }
    
    /// Saves current tint colors to UserDefaults and resets sliders
    @IBAction func saveBtn(_ sender: Any) {
        UserDefaults.standard.set(color: titleButton.tintColor ?? .black, forKey: "titleColor")
        UserDefaults.standard.set(color: authorButton.tintColor ?? .black, forKey: "authorColor")
        UserDefaults.standard.set(color: viewButton.tintColor ?? .white, forKey: "viewColor")
        
        // Reset sliders
        [redSlider, greenSlider, blueSlider].forEach { $0?.value = 0 }
        
        // Reload saved colors
        if let savedTitleColor = UserDefaults.standard.color(forKey: "titleColor") {
            titleButton.tintColor = savedTitleColor
        }
        if let savedAuthorColor = UserDefaults.standard.color(forKey: "authorColor") {
            authorButton.tintColor = savedAuthorColor
        }
        if let savedViewColor = UserDefaults.standard.color(forKey: "viewColor") {
            viewButton.tintColor = savedViewColor
        }
    }
    
    /// Resets theme colors to default values
    @IBAction func resetBtn(_ sender: Any) {
        titleButton.tintColor = .black
        authorButton.tintColor = .black
        viewButton.tintColor = .white
    }
    
    // MARK: - Slider Value Change Handlers
    
    @IBAction func redSliderChange(_ sender: Any) {
        updateSliderValues()
    }
    
    @IBAction func greenSliderChange(_ sender: Any) {
        updateSliderValues()
    }
    
    @IBAction func blueSliderChange(_ sender: Any) {
        updateSliderValues()
    }
    
    // MARK: - General Color Button Handler
    
    /// Applies slider color to the appropriate button using its tag (0 = title, 1 = author, 2 = view)
    @IBAction func buttonColorChange(_ sender: UIButton) {
        updateSliderValues()
        
        let selectedColor = UIColor(red: CGFloat(red), green: CGFloat(green), blue: CGFloat(blue), alpha: 1)
        
        switch sender.tag {
        case 0: titleButton.tintColor = selectedColor
        case 1: authorButton.tintColor = selectedColor
        case 2: viewButton.tintColor = selectedColor
        default: return
        }
    }
    
    // MARK: - Helper Functions
    
    /// Updates local RGB values based on current slider positions
    private func updateSliderValues() {
        red = redSlider.value
        green = greenSlider.value
        blue = blueSlider.value
    }
    
    /// Applies current slider RGB color to the given UIButton
    private func applySliderColor(to button: UIButton) {
        updateSliderValues()
        button.tintColor = UIColor(
            red: CGFloat(red),
            green: CGFloat(green),
            blue: CGFloat(blue),
            alpha: 1
        )
    }
}
