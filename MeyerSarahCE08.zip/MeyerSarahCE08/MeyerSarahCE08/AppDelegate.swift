//
//  AppDelegate.swift
//u

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    // Called after the app has launched successfully
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {

        // You can perform any custom setup here, such as analytics setup or theme configuration
        print("🚀 RedditPostViewer launched successfully.")
        return true
    }

    // MARK: - UISceneSession Lifecycle

    // Called when a new scene session is being created
    func application(_ application: UIApplication,
                     configurationForConnecting connectingSceneSession: UISceneSession,
                     options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        
        // Return the configuration used to create the new scene
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    // Called when the user discards a scene session
    func application(_ application: UIApplication,
                     didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        
        // This method is called shortly after application:didFinishLaunchingWithOptions
        // if the user discarded a scene session while the app was not running.
        // Release any resources specific to discarded scenes here, if needed.
    }
}

