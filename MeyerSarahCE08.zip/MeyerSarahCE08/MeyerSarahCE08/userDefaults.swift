//
//  userDefaults.swift
//  MeyerSarahCE08
//
//  Created by Sarah on 10/17/22.
//  Updated for portfolio use in 2025 by Sarah Meyer
//

import Foundation
import UIKit

// MARK: - UserDefaults Extension for Colors and Subreddits
extension UserDefaults {
    
    // MARK: - UIColor Storage
    
    /// Saves a UIColor to UserDefaults using secure archiving
    func set(color: UIColor, forKey key: String) {
        let binaryData = try? NSKeyedArchiver.archivedData(withRootObject: color, requiringSecureCoding: true)
        set(binaryData, forKey: key)
    }
    
    /// Retrieves a UIColor from UserDefaults using secure unarchiving
    func color(forKey key: String) -> UIColor? {
        guard let binaryData = data(forKey: key) else { return nil }
        return try? NSKeyedUnarchiver.unarchivedObject(ofClass: UIColor.self, from: binaryData)
    }
    
    // MARK: - Subreddit Array Storage
    
    /// Saves an array of subreddit names to UserDefaults
    func setSub(input: [String], forKey key: String) {
        let subData = try? NSKeyedArchiver.archivedData(withRootObject: input, requiringSecureCoding: true)
        set(subData, forKey: key)
    }
    
    /// Retrieves a saved array of subreddit names from UserDefaults
    func getSub(forKey key: String) -> [String]? {
        guard let data = data(forKey: key) else { return [""] }
        
        // Using deprecated unarchiver due to lack of modern Codable support for [String] + secureCoding
        if let subArray = try? NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(data) as? [String] {
            return subArray
        }
        return [""]
    }
}
