//
//  SubredditViewCell.swift
//  MeyerSarahCE08
//
//  Created by Sarah on 10/24/22.
//

import UIKit






class SubredditViewCell: UITableViewCell {
    @IBOutlet var subLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
