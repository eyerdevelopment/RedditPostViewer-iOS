//
//  TVC_EXT.swift
//  MeyerSarahCE08
//
//  Created by Sarah on 10/17/22.
//  Updated for portfolio use in 2025 by Sarah Meyer
//

import Foundation

// MARK: - Reddit Fetching & Filtering Extension
extension ViewController {
    
    /// Fetches posts from the chosen subreddit and updates the UI
    func subRedditPicker(chosenSubReddit: String) {
        
        guard let validURL = URL(string: "https://www.reddit.com/r/\(chosenSubReddit)/.json") else {
            print("Invalid subreddit URL.")
            return
        }
        
        let session = URLSession(configuration: .default)
        
        let task = session.dataTask(with: validURL) { data, response, error in
            
            // Bail out if there is a network error
            if let error = error {
                print("Network error: \(error.localizedDescription)")
                assertionFailure()
                return
            }
            
            // Ensure valid response and data
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200,
                  let jsonData = data else {
                print("Invalid response or no data.")
                assertionFailure()
                return
            }
            
            do {
                // Parse the JSON into a dictionary
                if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
                   let outerData = json["data"] as? [String: Any],
                   let children = outerData["children"] as? [[String: Any]] {
                    
                    // Clear current posts
                    self.posts.removeAll()
                    
                    // Loop through each post in the subreddit
                    for child in children {
                        if let postData = child["data"] as? [String: Any] {
                            do {
                                let post = try Post(jsonRedditPost: postData)
                                self.posts.append(post)
                            } catch {
                                print("⚠️ Failed to create Post: \(error)")
                                assertionFailure("Post Creation Failed.")
                            }
                        }
                    }
                }
            } catch {
                print("⚠️ JSON parsing error: \(error.localizedDescription)")
                assertionFailure()
            }
            
            // Update the UI on the main thread
            DispatchQueue.main.async {
                self.filterPostsBySubreddit()
                self.filteredPosts.append(self.posts)
                self.table.reloadData()
            }
        }
        
        task.resume()
    }
    
    /// Filters the parsed posts by saved subreddit names
    func filterPostsBySubreddit() {
        for (index, subName) in savedSub.enumerated() {
            filteredPosts[index] = posts.filter { $0.subReddit == subName }
        }
    }
}
